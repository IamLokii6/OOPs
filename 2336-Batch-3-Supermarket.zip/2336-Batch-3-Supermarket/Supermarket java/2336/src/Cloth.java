
public class Cloth extends SuperMarket{
	String men="shirt";
	String women="top";
	String kids="xyz";
	
	public void display() {
		System.out.println("Men:" +men);
		System.out.println("Women:" +women);
		System.out.println("Women:" +kids);
		
	}

}
