
public class Electronic {
	String TV="soni";
	String Microwave="philips";
	
	public void display() {
		System.out.println("T.V:" +TV);
		System.out.println("Microwave:" +Microwave);
	}
	
	}
