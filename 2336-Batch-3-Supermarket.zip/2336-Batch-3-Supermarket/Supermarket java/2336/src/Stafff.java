
public class Stafff {
	String casher="xyz";
	String bagger="xyz";
	String custodian="xyz";
	
	public void display() {
		System.out.println("casher:" +casher);
		System.out.println("bagger:" +bagger);
		System.out.println("custodian:" +custodian);
		}
}


