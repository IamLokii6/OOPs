
public class Food {
	String pericable="fish";
	String nonpericable="nuts";
	
	public void display() {
		System.out.println("Pericable: " +pericable);
		System.out.println("Nonpericable: " +nonpericable);
	}

	}

