
public class Stationary11 {
	String pen="cello";
	String books="camlin";
	
	public void display() {
		System.out.println("Pen:" +pen);
		System.out.println("Books:" +books);
		
	}
	

	}
