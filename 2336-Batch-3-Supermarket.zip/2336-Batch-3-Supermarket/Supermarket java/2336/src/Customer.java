
public class Customer {
	String cname="abc";
	String cnumber="123";
	
	 public void display() {
		 System.out.println("Customer name:" +cname);
		 System.out.println("Customer number:" +cnumber);
	 }
	}