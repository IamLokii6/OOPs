/**
 * 
 */
/**
 * 
 */
module My2dhouse {
	requires java.desktop;
}