/**
 * 
 */
/**
 * 
 */
module tug_of_war {
	requires java.desktop;
}